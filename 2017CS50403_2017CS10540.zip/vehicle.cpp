#include "vehicle.hpp"
using namespace std;

        Vehicle::Vehicle(Road *r, int len, int wid, string col, int max_sp, int acc, char disp, int i, vector<int> position)
        {
                rd = r;
                length = len;
                width = wid;
                id = i;
                color=col;
                max_speed=max_sp;
                acceleration=acc;
                pos = position;
                velocity.push_back(max_sp);
                velocity.push_back(0);
                display = disp;
                is_accident = false;
        }

        Vehicle::Vehicle(const Vehicle &obj)
        {
                rd=obj.rd;
                length = obj.length;
                width = obj.width;
                id = obj.id;
                color = obj.color;
                max_speed = obj.max_speed;
                acceleration = obj.acceleration;
                pos = obj.pos;
                velocity = obj.velocity;
                display = obj.display;
                is_accident = obj.is_accident;
        }
        int Vehicle::get_length() {return length;}
        int Vehicle::get_width() {return width;}
        int Vehicle::get_id() {return id;}
        string Vehicle::get_color() {return color;}
        int Vehicle::get_max_speed() {return max_speed;}
        int Vehicle::get_acceleration() {return acceleration;}
        vector<int> Vehicle::get_pos() {return pos;}
        vector<int> Vehicle::get_velocity() {return velocity;}
        int Vehicle::get_display_char() {return display;}
        int Vehicle::get_accident_truth() {return is_accident;}

        void Vehicle::set_acceleration(int acc) {acceleration=acc;}
        void Vehicle::set_pos(int x, int y) {pos[0]=x; pos[1]=y;}
        void Vehicle::set_velocity(vector<int> v) {velocity[0]=v[0]; velocity[1]=v[1];}
	void Vehicle::set_velocity(int x, int y) {velocity[0]=x; velocity[1]=y;}

	bool Vehicle::can_go_left()
	{
		if(pos[1]>=rd->get_length())
                {
                        return false;
                }
		return true;
	}

	bool Vehicle::can_go_right()
	{
		if(pos[1]<0)
                {
                        return false;
                }
		return true;
	}

        void Vehicle::update()
        {
		int acc=acceleration;
                if(acc>max_speed)
                {
                        acc=max_speed;
                }
                int vx=velocity[0]+acc;
		int vy=velocity[1];
		int px=pos[0]+vx+floor(acc/2);
                int py=pos[1]+vy;
                if(vx<0)
                {
                        acc=0;
                        vx=0;
                }
                else if(vx>max_speed)
                {
                        acc=0;
                        vx=max_speed;
                }

                if(py>=rd->get_length())
                {
                        py=rd->get_length()-1;
			vy=0;

                }
                else if(py<0)
                {
                        py=0;
			vy=0;
                }

		pos[0]=px;
		pos[1]=py;
		velocity[0]=vx;
                velocity[1]=0;
		if(acc<0)
		{
			acceleration=0;
		}
		else
		{
			acceleration=acc;
		}

        }
